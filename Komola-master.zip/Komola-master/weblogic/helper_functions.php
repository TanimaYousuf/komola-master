<?php
require_once($_SERVER['DOCUMENT_ROOT'] . "/komla_settings.php");
$komla = $_project['uiu'];

function redirect_to($url)
{
    header("Location: " . $url);
    die();
}


?>