<?php
require_once($_SERVER['DOCUMENT_ROOT'] . "/komla_settings.php");


?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    
</head>
<?php
function showMenu()
{
    ?>
    <div class="menu">
    <ul id="menu">

        <li><a href="<?php echo komla_url("pages/home.php")?>">Home</a></li>
        <li><a href="#">Study Materials</a>
            <ul>
                <li><a href="#">Books</a></li>
                <li><a href="#">Question Bank</a></li>

            </ul>
        </li>
        <li><a href="#">Contact us</a></li>
        <li><a href="#">Community</a></li>
    </ul>
    </div>
    <?php
}
function addCSS()
{
    ?>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <link rel="stylesheet" type="text/css" href="menustyle.css">
    <?php
}

?>
</html>
