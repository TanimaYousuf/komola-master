<?php
require_once($_SERVER['DOCUMENT_ROOT'] . "/komla_settings.php");
komla_require("/pages/common_elements.php");
$komla = $_project['uiu'];

?>

<html>

<head>
    <title><?php  echo "Welcome user";?></title>
    <?php addCSS(); /*Why is this a function? -_- */?>

</head>
<body>
<div class="main_container">
    <div class="banner">

    </div>
    <div class="menu_container">
        <?php showMenu(); ?>
    </div>

    <div class="profile_container">
        working?

    </div>
    <div class="news_container">
        <br><h2>News goes here<br></h2>
    </div>
    <br>
    <div class="chatbox_container">
        <h2>Chat here</h2>

    </div>
</div>

</body>
</html>
