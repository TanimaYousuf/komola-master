<?php
require_once($_SERVER['DOCUMENT_ROOT'] . "/komla_settings.php");
komla_require("/pages/common_elements.php");
?>

<html xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

<head>
    <title>University Student Portal by Project Komla Lebu</title>
    <?php addCSS() ?>
</head>
<body>
<div class="main_container" >
    <div class="menu_container">
        <?php showMenu(); ?>
    </div>
    <div class="login_container" style="align: left; width: 300px;">
        <form action= <?php echo komla_url("request_handler.php"); ?> method="post">
            <input type="hidden" name="type" value="login">
            <br>
            <label >ID* </label>
            <input type="text" name="id" style="float:right" placeholder="University ID" required>
            <br><br>
            <input type="password" name="password" style=" float:right" placeholder="Password" required>


            <label>Password*: </label>
            <br>
            <br>
            <input type="password" name="password_confirm" style=" float:right" placeholder="Password" required>
            <label>Confirm Password*: </label>
            <br><br>
            <input type="checkbox" required ><p style="margin-bottom: 10px; float: right">I've read & accept the
                <a href="<?php echo komla_url("pages/terms.php")?>" target="_blank">terms and conditions</p>
            <br>
            <input type="submit" name="register-button" value="Register" style="width: 100px; float: right;">
        </form>
    </div>
</div>
</body>
</html>