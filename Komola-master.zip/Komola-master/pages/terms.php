<?php
require_once($_SERVER['DOCUMENT_ROOT'] . "/komla_settings.php");
komla_require("pages/common_elements.php");

?>

<html xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

<head>
    <title>University Student Portal by Project Komla Lebu</title>
    <?php addCSS() ?>
</head>
<body>
<div class="main_container">

    <p id="terms"> O mor khoda!!</p>

</div>
</body>
</html>