<?php
require_once($_SERVER['DOCUMENT_ROOT'] . "/komla_settings.php");
komla_require("pages/common_elements.php");

?>

<html xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

<head>
    <title>University Student Portal by Project Komla Lebu</title>
    <?php addCSS() ?>
</head>
<body>
<div class="main_container">
    <div class="menu_container">
        <?php showMenu(); ?>
    </div>
    <div class="home_buttons_container" style="align: left; width: 300px;">
        <div class="button">
            <a href="login.php" class="button" id="LogIn_Button">Log In</a>
        </div>

        <div class="button">
            <a href="register.php" class="button" id="Register_Button" style="float: right">Register</a>
        </div>

    </div>

</div>
</body>
</html>