<?php
require_once($_SERVER['DOCUMENT_ROOT'] . "/komla_settings.php");
require_once($_SERVER['DOCUMENT_ROOT'] . "/pages/common_elements.php");

$komla = $_project['uiu'];

?>


<html>
<head>

</head>
<body>
<div style="position:relative; left: 33%;">
    <h1>Welcome to your Dashboard</h1>
    <p>Unfortunately we haven't made anything here yet :(</p>
    <a href= <?php echo $komla['url'] . "pages/test.html" ?> >Click here for a little test </a>
</div>
</body>
</html>
