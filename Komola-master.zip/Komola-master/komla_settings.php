<?php

$_project['uiu']['url'] = "/";

$_current_project = $_project['uiu'];

function set_project($p)
{
    global $_current_project;
    $_current_project = $p['url'];
}

function komla_url($str)
{
    global $_current_project;
    return $_current_project['url'] . $str;
}


function komla_require($str)
{
    global $_current_project;
    require_once($_SERVER['DOCUMENT_ROOT'] . $_current_project['url'] . $str);
}


