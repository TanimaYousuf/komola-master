<?php
require_once($_SERVER['DOCUMENT_ROOT'] . "/komla_settings.php");
$komla = $_project['uiu'];


require_once ($_SERVER['DOCUMENT_ROOT'] . $komla['url'] . "weblogic/helper_functions.php");
require_once ($_SERVER['DOCUMENT_ROOT'] . $komla['url'] . "komola/db_handler.php");


    session_start();
    $error = @$_SESSION['error'] ;
?>
<html xmlns="http://www.w3.org/1999/html">
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    </head>
    <body>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    
                <form name="logIn" id="logIn" method="post" action="db_handler.php"  >
                    <div class="form-group">
                        <label>User ID</label>
                        <input type="text" name="userId" id="userId" class="form-control"  placeholder="your uni id" value=" ">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="userPass" id="userPass" class="form-control"  placeholder="Password" value="">
                    </div>
                    <button type="submit" class="btn btn-default" name="submit" value="logIn">Login</button>
                    <button type="submit" class="btn btn-default" name="submit" value="registration">Registration</button>
                </form>
                </div>
            </div>
        </div>
        <h3 align="center">
            <?php
            if($error){
                echo $error ;
                $_SESSION['error']=" ";
            }
            ?>
        </h3>
    </section>
    </body>
 </html>