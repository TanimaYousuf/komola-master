<?php
    /******************************************* ARRAY FOR FILE CATEGORY **************************************************/
    $fileCategory = array("Term Question Paper","Class Test","Project","Book","Notes","Slides","Practice material","Lab Assignment","Assignment","Others") ;

    /******************* ARRAY FOR TERM *******************/
    $term = array("Mid Term","Final","Other") ;

    /******************* ARRAY FOR SEMESTER **********************/
    $semester = array("Summer","Spring","Fall","Other") ;

    /********************* STARTING YEAR *************************/
    $startingYr = 2014 ;
    /***************** FILE COUNTER ************************/
    static $fileIdNo = 1 ;
    /********************** current time in sec ***************************/
    $time = time();
    /***************************** FILE EXTENSION ***********************************/
    $acceptedExtensions = array("cpp","c","css","class","doc","docx","html","java","jar","jpg","js","pdf","php","png","ppt","pps","pptx","rar","sql","txt","xls","zip");
?>