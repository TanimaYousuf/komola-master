<?php
  function db_handler()
  {
      if (isset($_POST['submit'])) {
          extract($_POST);
          $con = mysql_connect('localhost', 'komlalebu_admin','@123@lh@qwerty');
          mysql_select_db('komlalebu_uiu',$con);
          switch ($submit) {
              // ************************************* LOGIN QUERY *********************/
              case "logIn":
                  if ($userId != '' && $userPass != '') {
                      $sql = mysql_query("select * from user where user_id='$userId'and user_password='$userPass'");
                      if ($data = mysql_fetch_array($sql)) {
                          session_start();
                          $_SESSION['userId'] = $data['user_id'];
                          $_SESSION['userPass'] = $data['user_password'];
                          $_SESSION['userCategory'] = $data['user_category'];
                          return true;
                      } else {
                          session_start();
                          $_SESSION['error'] = "invalid user id or password";
                          return false;
                      }
                  } else {
                      $_SESSION['error'] = "fill both id and password field up";
                      return false;
                  }
                  break;
              // ******************************************** REGISTRATION QUERY  *********************************************/
              case "registration":
                  $flag = 0;
                  if ($userId != '' && $userPass != '') {
                      $sql = mysql_query("select user_id from user");
                      while ($data = mysql_fetch_array($sql)) {
                          if ($data['user_id'] == $userId) {
                              $flag = 1;
                              break;
                          }
                      }

                      if ($flag == 0) {
                          $insertSql = mysql_query("insert into user (user_id,user_password) values('$userId','$userPass')");
                          return true;
                      } else {
                          session_start();
                          $_SESSION['error'] = "u r already registered !!";
                          return false;
                      }
                  } else {
                      $_SESSION['error'] = "fill both id and password field up";
                      return false;
                  }
                  break;
              /****************************** FILE UPLOAD QUERY ***********************************************************/
              case "fileUpload":

                  $errorMsg = array();
                  if (isset($_FILES['fileImage'])) {
                      $path = "fileImage/";
                      $fileName = $_FILES['fileImage']['name'];
                      $fileSize = $_FILES['fileImage']['size'];
                      $fileTmp = $_FILES['fileImage']['tmp_name'];
                      $fileType = $_FILES['fileImage']['type'];
                      $filePath = $path . basename($fileName);
                      $fileInfo = pathinfo($filePath);
                      $fileExtension = $fileInfo['extension'];
                      /*
                                          $flag = 0 ;

                                         require_once('arraySelection.php');
                                         for($i=0 ; $i<count($acceptedExtensions) ; $i++){
                                              if(in_array($fileExtension,$acceptedExtensions[$i])==false) {
                                                      $flag = 1 ;
                                              }
                                          }

                                          if($flag!=0){
                                              $errorMsg[] = "THIS EXTENSION IS NOT ALLOWED";
                                          }
                      */

                      if ($fileSize > 2097152) {
                          $errorMsg[] = "FILE IS TOO BIG !!";
                      }

                      if (empty($errorMsg) == true) {
                          move_uploaded_file($fileTmp, "fileImage/" . $fileName);
                      } else {
                          session_start();
                          $_SESSION['msg'] = $errorMsg;
                          header("location:fileUpload.php");

                      }

                  }

                  if (file_exists($filePath) || is_uploaded_file($filePath)) {
                      mysql_query("insert into file values(' ','$fileName','$fileDescription','$courses','$file_category','$fileTerm','$fileSemester','$year','$faculty','$fileOwner')");
                      session_start();
                      $_SESSION['msg'] = "FILE UPLOADED SUCCESSFULLY";
                      header("location:fileUpload.php");
                  } else {
                      session_start();
                      $_SESSION['msg'] = "FILE IS NOT UPLOADED PROPERLY !!";
                  }


                  break;
              /*********************************************************** CREATE COURSES QUERY **********************************************************/
              case "createCourse":

                  $flag = 0;

                  if (!empty($_POST['courseId']) && !empty($_POST['courseName'])) {
                      $courseSql = mysql_query("select * from course");
                      while ($data = mysql_fetch_array($courseSql)) {

                          $data['course_id'] = str_replace(' ', '', $data['course_id']);
                          $data['course_id'] = strtoupper($data['course_id']);
                          $data['course_name'] = str_replace(' ', '', $data['course_name']);
                          $data['course_name'] = strtoupper($data['course_name']);

                          $courseId = str_replace(' ', '', $courseId);
                          $courseId = strtoupper($courseId);
                          $courseName = str_replace(' ', '', $courseName);
                          $courseName = strtoupper($courseName);

                          if ($data['course_id'] == $courseId) {
                              $flag = 1;
                              break;
                          } else if ($data['course_name'] == $courseName) {
                              $flag = 2;
                              break;
                          }
                      }

                      $courseId = strtoupper($courseId);
                      $courseName = ucfirst(strtolower($courseName));

                      if ($flag <= 0) {
                          $insertSql = mysql_query("insert into course (course_id,course_name) values('$courseId','$courseName')");
                          session_start();
                          $_SESSION['msg'] = "ok";
                          header("location:createCourse.php");
                      } else if ($flag > 0) {
                          session_start();
                          $_SESSION['msg'] = "This course already exists !!! ";
                          header("location:createCourse.php");
                      }

                  } else {
                      session_start();
                      $_SESSION['msg'] = "please fill both the fields";
                      header("location:createCourse.php");
                  }

                  break;
          }//end of switch case
      }//1st if
  }
  db_handler() ;

?>