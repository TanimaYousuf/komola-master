<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    <h2>     </h2>
    <h2>     </h2>
    <table class="table table-striped" >
        <tr>
            <th>  </th>
            <th>COURSES FOR AVAILABLE FILES</th>
            <th>  </th>
        </tr>
        <?php
            include ('db.php');
            $sql = mysql_query("select * from course order by course_name ") ;
            while ($data = mysql_fetch_row($sql)) {
                echo "<tr>";
                echo "<td>  </td>";
                echo "<td>" . "<a href='showFile.php?selectedCourse=".$data[1]."'>".$data[1]."</a>" . "</td>";
                echo "<td>  </td>";
                echo "</tr>";
            }
        ?>

    </table>
</div>

</body>
</html>
