<?php
    session_start() ;
    $userId = @$_SESSION['userId'] ;
    $msg = @$_SESSION['msg'] ;
/* $userCategory = $_SESSION['userCategory'] ;*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    <h2>Create Course : </h2>
    <form class="form-horizontal" role="form" method="post" action="db_handler.php" enctype="multipart/form-data">

        <!--------------------------------- COURSE ID ----------------------------------------------->
        <div class="form-group">
            <label class="control-label col-sm-2">COURSE ID :</label>
            <div class="col-sm-10">
                <input type="text" name="courseId" id="courseId" class="form-control input-lg" >
            </div>
        </div>
        <!-------------------------------------------- COURSE NAME ------------------------------------------------->
        <div class="form-group">
            <label class="control-label col-sm-2" for="pwd">COURSE NAME:</label>
            <div class="col-sm-10">
                <input type="text" name="courseName" id="courseName" class="form-control input-lg" >
            </div>
        </div>

        <!--------------blank div---------------------->
        <div class="form-group">

        </div>
        <!--------------blank div---------------------->
        <!------------------ SUBMIT BUTTON ---------------------------->
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-default" name="submit" value="createCourse" id="createCourse">Create Course</button>
                <button type="reset" class="btn btn-default" name="submit" value="createCourse" id="createCourse">Reset</button>
            </div>
        </div>
    </form>
    <p>
        <?php
        if($msg){
            echo $msg ;
            $_SESSION['msg'] = '';
        }
        else
        {
            echo "<p>&nbsp;</p>";
        }
        ?>
    </p>
</div>

</body>
</html>
