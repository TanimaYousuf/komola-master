<?php
require_once($_SERVER['DOCUMENT_ROOT'] . "/komla_settings.php");
$komla = $_project['uiu'];


require_once ($_SERVER['DOCUMENT_ROOT'] . $komla['url'] . "weblogic/helper_functions.php");
require_once ($_SERVER['DOCUMENT_ROOT'] . $komla['url'] . "komola/db_handler.php");


    session_start() ;
    $userId = $_SESSION['userId'] ;
    $msg = @$_SESSION['msg'] ;
   /* $userCategory = $_SESSION['userCategory'] ;*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    <h2>File Upload</h2>
    <form class="form-horizontal" role="form" method="post" action=<?php echo $komla['url'] . "request_handler.php" ?> enctype="multipart/form-data">
        <input type="hidden" name="type" value="fileUpload">
        <!-------------------------- FILE ID ----------------------------------------
        <div class="form-group">
            <label class="control-label col-sm-2" for="pwd">File ID:</label>
            <div class="col-sm-10">
                <?php
                include 'arraySelection.php' ;
                $fileNo = "$fileIdNo"."_"."$time";
                echo "<input type='text' class='form-control' id='' name='' value='$fileNo'>" ;
                ?>
            </div>
        </div>
        ----->
        <!--------------------------------- UPLOAD THE FILE ----------------------------------------------->
        <div class="form-group">
            <label class="control-label col-sm-2">File :</label>
            <div class="col-sm-10">
                <input type="file" class="btn btn-default btn-file" name="fileImage" id="fileImage" value=" ">
            </div>
        </div>
        <!-------------------------------------------- DESCRIPTION ------------------------------------------------->
        <div class="form-group">
            <label class="control-label col-sm-2" for="pwd">File Description:</label>
            <div class="col-sm-10">
                <textarea class="form-control" rows="5" id="fileDescription" name="fileDescription"></textarea>
               <!----<input type="text" name="fileDescription" class="form-control input-lg" >-->
            </div>
        </div>
        <!--------------------------------------- COURSES ------------------------------------------------------->
        <div class="form-group">
            <label class="control-label col-sm-2" for="pwd">Course:</label>
            <div class="col-sm-10">
                <select name="courses" value="courses" class="form-control" id="sel1">
                    <option value=" ">----------------Select-----------</option>
                    <?php
                     $i = 1 ;
                    connect_database();
                    $sql = mysql_query("select * from course");
                    while($row = mysql_fetch_row($sql)){
                        echo "<option value='$row[$i]'>$row[0]  $row[$i]</option>" ;
                    }
                    ?>
                    <option>---------------------</option>
                    <option><a href="#">Create Course</a></option>
                </select>
            </div>
         </div>
        <!---------------------------------- FILE CATEGORY --------------------------------------------------------------->
        <div class="form-group">
            <label class="control-label col-sm-2" for="pwd">File Category:</label>
            <div class="col-sm-10">
                <select name="file_category" value="file_category" class="form-control" id="sel1">
                    <option value=" " >----------------Select-----------</option>
                    <?php
                        include 'arraySelection.php' ;
                        foreach ($fileCategory as $item) {
                            echo "<option value='$item'>$item</option>";
                        }
                    ?>
                </select>
            </div>
        </div>
        <!------------------------------------------- TERM -------------------------------------------------------->
        <div class="form-group">
            <label class="control-label col-sm-2" for="pwd">Term :</label>
            <div class="col-sm-10">
                <select name="fileTerm" value="fileTerm" class="form-control" id="sel1">
                    <option value=" ">----------------Select-----------</option>
                    <?php
                    require_once ('arraySelection.php') ;
                    foreach ($term as $item) {
                        echo "<option value='$item'>$item</option>";
                    }
                    ?>

                </select>
            </div>
        </div>
        <!---------------------------------- SEMESTER -------------------------------------------------------------------->
        <div class="form-group">
            <label class="control-label col-sm-2" for="pwd">Semester:</label>
            <div class="col-sm-10">
                <select name="fileSemester"  class="form-control" id="sel1">
                    <option value=" ">----------------Select-----------</option>
                    <?php
                    include 'arraySelection.php' ;
                    foreach ($semester as $item) {
                        echo "<option value='$item'>$item</option>";
                    }
                    ?>
                </select>
            </div>
        </div>
        <!-------------------------------------------- FILE YEAR -------------------------------------------------------->
        <div class="form-group">
            <label class="control-label col-sm-2" for="pwd">Year :</label>
            <div class="col-sm-10">
                <select name="year" class="form-control" id="sel1">
                    <option value=" ">----------------Select-----------</option>
                    <?php
                        include 'arraySelection.php';
                        for($i=$startingYr ; $i<=date("Y") ;$i++){
                            echo "<option value='$i'>$i</option>";
                        }
                    ?>
                    <option value="">Others</option>
                </select>
            </div>
        </div>
        <!------------------------------------------ FACULTY ------------------------------------------------------------->
        <div class="form-group">
            <label class="control-label col-sm-2" for="pwd">Faculty :</label>
            <div class="col-sm-10">
                <input type="text" name="faculty" id="faculty" class="form-control input-sm">
            </div>
         </div>
        <!-------------------------------------------- FILE OWNER -------------------------------------------------------------->
        <div class="form-group">
            <label class="control-label col-sm-2" for="pwd"></label>
            <div class="col-sm-10">
                <?php
                    echo "<input type='hidden' name='fileOwner' value='$userId'>" ;
                ?>
               <!-- <input type="text" name="" value="">-->
            </div>
        </div>
        <!--------------blank div---------------------->
        <div class="form-group">

        </div>
        <!--------------blank div---------------------->
        <!------------------ SUBMIT BUTTON ---------------------------->
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-default" name="submit" value="fileUpload" id="fileUpload">File Upload</button>
                <button type="reset" class="btn btn-default" name="submit" value="fileUpload" id="fileUpload">Reset</button>
            </div>
        </div>
    </form>
    <p>
        <?php
            if($msg){
                echo $msg ;
                $_SESSION['msg'] = ' ';
            }
            else
            {
                echo "<p>&nbsp;</p>";
            }
        ?>
    </p>
</div>

</body>
</html>
