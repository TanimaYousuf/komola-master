<?php
    $con = mysql_connect('localhost', 'komlalebu_admin','@123@lh@qwerty');
    mysql_select_db('komlalebu_uiu',$con);

?>