<?php
require_once($_SERVER['DOCUMENT_ROOT'] . "/komla_settings.php");
$komla = $_project['uiu'];

require_once ($_SERVER['DOCUMENT_ROOT'] . $komla['url'] . "weblogic/helper_functions.php");
require_once ($_SERVER['DOCUMENT_ROOT'] . $komla['url'] . "komola/db_handler.php");


if($_POST['type'] == "login"){
    $_POST['submit'] = "logIn";
    $_POST['userId'] = $_POST['id'];
    $_POST['userPass'] = $_POST['password'];
    $result = db_handler();
    if($result == TRUE)
        redirect_to($komla['url'] . "pages/user_dashboard.php");
    else
        redirect_to($komla['url']. "index.php");
}
else if($_POST['type'] == "register"){
    $_POST['submit'] = "registration";
    $_POST['userId'] = $_POST['id'];
    $_POST['userPass'] = $_POST['password'];
    $result = db_handler();
    if($result == TRUE){
        $_POST['submit'] = "logIn";
        $result = db_handler();
        if($result == TRUE)
            redirect_to($komla['url'] . "pages/user_dashboard.php");
        else
            redirect_to($komla['url']. "index.php");
    }
    else
        redirect_to($komla['url']. "index.php");
}
else if($_POST['type'] == "fileUpload"){
    $DATA = $_POST;
    $DATA['submit'] = "fileUpload";
    $result = db_handle($DATA, $_FILES);
    redirect_to($komla['url']. "index.php");

}
else if($_POST['type'] == "logout"){
    session_start();
    $_SESSION = array();
    redirect_to($komla['url']. "index.php");
}
else{
    redirect_to($komla['url']. "index.php");
}

?>