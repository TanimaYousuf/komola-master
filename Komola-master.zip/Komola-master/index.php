<?php
require_once($_SERVER['DOCUMENT_ROOT'] . "/komla_settings.php");
$komla = $_project['uiu'];

$mainpage = $komla['url'] . "pages/home.php";
header("Location: " . $mainpage);
die();
?>


